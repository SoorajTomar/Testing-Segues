//
//  ViewController.swift
//  testing
//
//  Created by admin on 03/11/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ageValue: UISlider!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var phNo: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var eMail: UITextField!
    @IBOutlet weak var dob: UITextField!
    @IBOutlet weak var fName: UITextField!
    @IBOutlet weak var lName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func getAge(_ sender: Any) {
        age.text="\(Int(ageValue.value))"+" Years"
    }
    @IBAction func getDob(_ sender: Any) {
        let val=DateFormatter()
        val.dateStyle=DateFormatter.Style.short
        dob.text=val.string(from: datePicker.date)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            
        // Create a variable to store the name the user entered on textField
        let nickName = fName.text!
        // Create a new variable to store the instance of the SecondViewController
        // set the variable from the SecondViewController that will receive the data
        let destinationVC = segue.destination as! ConfirmedDataViewController
        destinationVC.name = nickName
    }
}
