//
//  ViewController.swift
//  Control trials
//
//  Created by admin on 07/11/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myCountdown: UILabel!
    @IBOutlet weak var sliderVar: UISlider!
    @IBOutlet weak var switchView: UISwitch!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var greet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
            myCountdown.text="40 Days"
        
        
        // Do any additional setup after loading the view.
    }
    @IBAction func getAge(_ sender: Any) {
        age.text="\(Int(sliderVar.value)) Years"
    }
    @IBAction func switchDone(_ sender: Any) {
        if switchView.isOn{
            view.backgroundColor = .white
        }
        else{
            view.backgroundColor = .gray
        }
    }
    @IBAction func displayDetails(_ sender: Any) {
        if name.text! != "" && age.text! != ""{
        greet.text = """
    Hello \(name.text!).
    You are \(age.text!) old.
    Nice to meet you!
"""
        }
        else{
            greet.text="""
Uh oh!
Kindly enter the details as intended.
"""
        }
    }
}

